AERROSTRIKE X — ダウンロード版

ZIPを展開し、AERROSTRIKE-X.htmlをブラウザで開いてください。外部素材の取得は不要です。
PC：WASD／矢印キーで移動。X：武器切替、SPACE：爆弾、C：火力2倍、P：一時停止。
タッチ：ドラッグで移動。下のアイコンはタップで選択、ドラッグで移動。
音は出撃などの操作後に開始します。

iPhoneの「ファイル」内のプレビューではJavaScriptゲームが動かないことがあります。その場合は公開URLをSafariで開いてください。
https://aerrostrike-x-afterburn.cuichunxue1984.chatgpt.site

sourceフォルダは編集用の分割ソースです。テストはsourceをdistという名前に変更した構成で node tests/game-state.cjs を実行します。
記録はブラウザ内に保存され、公開版とローカル版で共有されません。iPhone実機での動作は未確認です。
