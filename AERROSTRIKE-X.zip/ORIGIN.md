Adapted from the user-supplied project: https://github.com/cuichunxue/AerroStrikeX/blob/main/index.html
Original file SHA: 0872359dcc26ed26071c29f0148ea939f001e9b0

Preserves the original arcade shooting concept, four weapon types, bombs, pickups, and local high score. Rebuilds the timing, collision, input, rendering and UI layers; adds synthesized audio, bosses, combo scoring, graze energy and per-sector upgrades. No third-party art, music or runtime dependencies.

Run by serving dist as a static website. Score and mute settings are stored only in the current browser. Audio starts after a user gesture. Sites edition is separate from the original GitHub Pages deployment.
